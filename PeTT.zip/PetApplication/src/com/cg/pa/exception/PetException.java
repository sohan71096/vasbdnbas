package com.cg.pa.exception;

public class PetException extends Exception 
{

	public PetException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
